from collections import namedtuple

Properties = namedtuple('CSVProperties', 'encoding delimiter quotechar')
