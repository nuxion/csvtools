# GENERAL

## dist file

```
    python setup.py sdist
```
check: https://www.digitalocean.com/community/tutorials/how-to-package-and-distribute-python-applications
